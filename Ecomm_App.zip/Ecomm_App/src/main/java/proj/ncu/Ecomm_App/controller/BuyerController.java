package proj.ncu.Ecomm_App.controller;

import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import proj.ncu.Ecomm_App.DAO.BuyerDAOImpl;
import proj.ncu.Ecomm_App.Entity.BuyerPOJO;

@Controller
public class BuyerController {
	
	@Autowired
	BuyerDAOImpl buyerDAOImp;

	@ModelAttribute("sellerPOJO")
	public BuyerPOJO getBuyerPOJO() {
		return new BuyerPOJO();
	}

	@RequestMapping(value = "/1")
	public ModelAndView test(HttpServletResponse response, HttpServletRequest req) throws IOException {
		HttpSession session = req.getSession();
		int id = 0;
		System.out.println("this is id " + session.getAttribute("orderid"));
		if (session.getAttribute("orderid") == null) {
			System.out.println("bruhh");
			id = 0;
		}
		System.out.println(session.getAttribute("orderid"));
		session.setAttribute("orderid", id);
		return new ModelAndView("home");
	}

	@RequestMapping(value = "/userType1")
	public String getUserType() {
		return "userType";
	}
	
	@RequestMapping(value = "/buyerLogin")
	public String getBuyerLogin() {
		return "buyerLogin";
	}

	@RequestMapping(value = "/buyerRegister")
	public String getBuyerRegister() {
		return "buyerRegister";
	}

	@RequestMapping(value = "/buyerView")
	public String getBuyerView() 
	{
		return "buyerView";
	}
	
	@RequestMapping(value="/validateBuyer")
	public RedirectView validatebuyer(@RequestParam("pass")String pass,@RequestParam("username")String username)
	{
		System.out.println(username);
		System.out.println(pass);
		boolean is = buyerDAOImp.validateBuyer(username, pass);
		if(is) 
		{
			return new RedirectView("/Ecomm_App/buyerView2");
		}
		return new RedirectView("/Ecomm_App/buyerLogin");
	}
	
	@RequestMapping(value="/buyerView1")
	public RedirectView getBuyerView1()
	{
		return new RedirectView("/Ecomm_App/buyerView");
	}
	
	@RequestMapping(value= "/buyerView2")
	public RedirectView getBuyerConfirm2()
	{
		return new RedirectView("/Ecomm_App/buyerView");
	}
	
}
