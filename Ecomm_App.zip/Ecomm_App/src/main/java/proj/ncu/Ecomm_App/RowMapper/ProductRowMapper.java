package proj.ncu.Ecomm_App.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import proj.ncu.Ecomm_App.Entity.ProductPOJO;

public class ProductRowMapper implements RowMapper<ProductPOJO> {

	@Override
	public ProductPOJO mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		ProductPOJO pojo=new ProductPOJO();
		
		pojo.setId(rs.getInt(1));
		pojo.setName(rs.getString(2));
		pojo.setCategory(rs.getString(3));
		pojo.setPrice(rs.getInt(4));
		pojo.setDescription(rs.getString(5));
		pojo.setQuantity(rs.getInt(6));
		return pojo;
	}

}
