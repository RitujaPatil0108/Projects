package proj.ncu.Ecomm_App.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import proj.ncu.Ecomm_App.Entity.BuyerPOJO;

public class BuyerRowMapper implements RowMapper<BuyerPOJO>
{

	@Override
	public BuyerPOJO mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		BuyerPOJO spojo = new BuyerPOJO();
		
		spojo.setUsername(rs.getString(1));
		spojo.setPassword(rs.getString(2));
		spojo.setEmail(rs.getString(3));
		return spojo;
	}

}
