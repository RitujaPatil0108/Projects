package proj.ncu.Ecomm_App.DAO;

import java.util.List;

import proj.ncu.Ecomm_App.Entity.BuyerPOJO;

public interface BuyerDAO 
{
	public List<BuyerPOJO> getBuyer(String username);
	
	public void addBuyer(BuyerPOJO buyerpojo);
	
	public boolean validateBuyer(String username,String password);
}