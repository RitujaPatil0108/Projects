package AdminPortal;

public class AdminVerify
{

    final private String AdminId = "Ars111";
    final private String AdminPassword="admin";

    public String getAdminId()
    {
        return AdminId;
    }
    public String getAdminPassword()
    {
        return AdminPassword;
    }

}
