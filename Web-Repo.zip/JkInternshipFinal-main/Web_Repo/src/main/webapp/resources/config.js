const MY_API_KEY = 'paste your API key here';
export { MY_API_KEY };